package testcases;

import static org.hamcrest.Matchers.equalTo;

import java.util.HashMap;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

//import com.restTests.POJOs.LoginDataPOJO;
//import com.restTests.POJOs.LoginResponsePOJO;
import com.google.gson.JsonObject;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
//import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;

public class TC_TestBasicMethods {

	String extractedToken = null;

	@BeforeClass

	public void init() {
		RestAssured.baseURI = "https://dummy.restapiexample.com/api/v1";
	}

	@Test(enabled = true, priority = 1)
	public void getEmployeeCount() {

		Response res = RestAssured.given()
				.when()
					.get("/employees");

		res
			.then()
			.contentType(ContentType.JSON)
			.statusCode(200)
			.log().body(true)
			.extract().response();

		String jsonResString = res.asString();
		Assert.assertEquals(jsonResString.contains("success"), true);

		// int empcount=res.body().jsonPath().get("data.id[]").length();
		// System.out.println("total number of employes are="+empcount);

		System.out.println("total number of records=" + res.body().jsonPath().get("size()"));
	}

	@Test(enabled = true, priority = 2)
	public void createEmpRecord() {
		
		@SuppressWarnings("rawtypes")
		HashMap data = new HashMap();
		data.put("name", "test");
		data.put("salary", "123");
		data.put("age", "23");

		Response res = RestAssured.given()

				.contentType(ContentType.JSON)
				.body(data)
				
			.when()
				.post("/create");

		res
		.then()
			.statusCode(200)
			.contentType(ContentType.JSON)
			.body("data.employee_name", equalTo("test"))
			.body("data.employee_salary", equalTo("123"))
			.body("data.employee_age", equalTo("23"))
			.log().body(true)
			.extract().response();

		String jsonResString = res.asString();
		Assert.assertEquals(jsonResString.contains("success"), true);

		/*
		 * extractedToken= res.body().jsonPath().getString("[0].token");
		 * System.out.println("token extracted from jsonpath="+extractedToken);
		 */
	}

	@Test(enabled = true, priority = 3)
	public void delID() {
		Response res = RestAssured.given()

				.contentType(ContentType.JSON)
			.when()
				.delete("/0");

		res
			.then()
				.statusCode(400)
				.contentType(ContentType.JSON)
				.log().body(true)
				.extract().response();

		String jsonResStatus = res.asString();
		Assert.assertEquals(jsonResStatus.contains("error"), true);

		String errmsg = res.body().jsonPath().get("message");
		System.out.println("response message is =" + errmsg);
	}

	@Test(enabled = true, priority = 4)
	public void getEmp() {
		
		JsonObject json = new JsonObject();

		Response res = RestAssured.given()

				.contentType(ContentType.JSON)
			.when()
				.get("/2");

			res
				.then()
					.statusCode(200)
					.contentType(ContentType.JSON)
					.log().body(true)
					.body("data.employee_name", equalTo("Garrett Winters"))
					.body("data.employee_salary", equalTo(" 170750 "))
					.body("data.employee_age", equalTo("63")).extract()
					.response();
	}

}
